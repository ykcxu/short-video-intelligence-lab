# 数据质量报表（v1）

- 生成时间：2026-04-28T07:19:54.732323+00:00
- 工作区：C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab

## 扫描范围
- detail 文件：669（视频 623）
- comments 文件：518（视频 388）
- downloads 文件：630（视频 620）

## 异常统计
- 无效 video_id：6（detail=3，comments=2，downloads=1）
- 下载无 detail：0
- detail 无下载：3
- 指标异常：34
- placeholder 评论：487
- empty_comment_state：20
- 非空评论视频数：381

## 覆盖差异（前 20）
- 下载无 detail：无
- detail 无下载：1234567890、7356441851857063180、7377711055939570944

## 指标异常样例（前 10）
- 7631153680381495910：all_equal_non_zero（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_1fcf9a7783_20260423T103847819925_plus_0000.json）
- 7022771022038388255：all_equal_non_zero（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_228c7d5d51_20260423T074945504530_plus_0000.json）
- 7395782642211294490：all_equal_non_zero（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_347cfb7a86_20260423T090100592232_plus_0000.json）
- 7516480886684568891：all_equal_non_zero（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_4111975deb_20260423T075921103931_plus_0000.json）
- 7516480886684568891：all_equal_non_zero（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_4111975deb_20260424T024036867896_plus_0000.json）
- 7353800432654863635：all_equal_non_zero（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_42f4b29c4e_20260423T085806070623_plus_0000.json）
- 7158035664578120992：all_equal_non_zero、huge_value（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_4cb1858e5c_20260423T102442635784_plus_0000.json）
- 7594044392240487144：all_equal_non_zero（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_4d78d6e364_20260423T093512871007_plus_0000.json）
- 7592835997059008403：huge_value（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_5b76f49849_20260424T090247470963_plus_0000.json）
- 7628561969506684195：all_equal_non_zero（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_5d91d95309_20260421T102112924281_plus_0000.json）

## 无效 video_id 样例（前 10）
- [detail] detected=undefined path=C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_18e53ade07_20260423T092533887250_plus_0000.json
- [detail] detected=test2 path=C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_4c7c24b884_20260423T074746615840_plus_0000.json
- [detail] detected=test1 path=C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\video\video_detail_ce8a6e9526_20260421T073651771942_plus_0000.json
- [comments] detected=test1 path=C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\comments\video_comments_ce8a6e9526_20260421T073700370112_plus_0000.json
- [comments] detected=test1 path=C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\collector\comments\video_comments_ce8a6e9526_20260421T081012245484_plus_0000.json
- [downloads] detected=undefined path=C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\downloads\artifact\子琦老师讲语文\子琦老师讲语文_undefined.mp4
