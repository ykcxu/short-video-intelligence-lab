# 评论补采命中率诊断

## 总体指标

- 视频总数：272
- 真实评论视频数：0
- 失败视频数：272
- 页面明确无评论视频数：5
- 平台显示无评论视频数：131
- 平台显示有评论但未取到视频数：136
- 命中率：0.00%

## 视频状态分布

| 状态 | 视频数 |
| --- | ---: |
| real_comment | 0 |
| empty_response | 7 |
| noise_only | 30 |
| missing_artifact | 235 |

## 评论预期分类

| 分类 | 视频数 |
| --- | ---: |
| real_comment | 0 |
| no_comment_observed | 5 |
| no_comment_expected | 131 |
| comment_expected_empty_response | 4 |
| comment_expected_noise_only | 25 |
| comment_expected_missing_artifact | 107 |

## 失败原因聚合

### empty_response

- `scan_meta.warning:dom_json_extraction_used`：22
- `scan_meta.backend:playwright:placeholder`：14
- `scan_meta.stop_reason:placeholder_only`：14
- `scan_meta.warning:networkidle timeout while probing comment page`：14
- `scan_meta.warning:comment_panel_activation_not_confirmed`：8
- `scan_meta.warning:dom_regex_extraction_used`：6
- `scan_meta.backend:stub:no_playwright`：1
- `scan_meta.stop_reason:no_playwright`：1
- `scan_meta.warning:playwright is not installed`：1

### noise_only

- `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/`：278
- `raw.response_url:live.douyin.com/webcast/setting/`：248
- `scan_meta.warning:dom_json_extraction_used`：222
- `scan_meta.warning:network_response_comment_extraction_used`：134
- `scan_meta.warning:comment_panel_activation_not_confirmed`：94
- `scan_meta.warning:networkidle timeout while probing comment page`：94
- `scan_meta.warning:comment response parse failed: https://mcs.zijieapi.com/list?aid=6383&sdk_version=5.1.24_dy: Response.json: Protocol error (Network.getResponseBody): No resourc`：62
- `scan_meta.warning:comment response parse failed: https://sf1-cdn-tos.douyinstatic.com/obj/accessibility-task-platform/entrance/a11y_web_init.js: Expecting value: line 1 column 1 `：57
- `scan_meta.backend:playwright:placeholder`：48
- `scan_meta.stop_reason:placeholder_only`：48
- `scan_meta.backend:playwright:network-response-v1`：31
- `scan_meta.stop_reason:network_response_comments_captured`：31
- `scan_meta.warning:comment response parse failed: https://mcs.zijieapi.com/list: Response.json: Protocol error (Network.getResponseBody): No resource with given identifier found`：31
- `scan_meta.warning:comment response parse failed: https://mcs.zijieapi.com/list: Response.json: Target page, context or browser has been closed`：29
- `scan_meta.warning:comment response parse failed: https://www.douyin.com/aweme/v1/web/set/user/settings?aid=6383&channel=channel_pc_web&device_platform=webapp&select_duration=0&se`：26
- `raw.response_url:www.douyin.com/aweme/v2/web/module/feed/`：26
- `scan_meta.backend:playwright:placeholder-error`：20
- `scan_meta.stop_reason:playwright_placeholder_error`：20
- `scan_meta.stop_reason_detail:[Errno 2] No such file or directory: 'C:\\Users\\Administrator\\Desktop\\codex\\short-video-intelligence-lab\\data\\sessions\\douyin\\state.json'`：20
- `scan_meta.warning:playwright placeholder comment scan failed: [Errno 2] No such file or directory: 'C:\\Users\\Administrator\\Desktop\\codex\\short-video-intelligence-lab\\data\\`：20
- `scan_meta.backend:playwright:empty-state`：15
- `scan_meta.stop_reason:empty_comment_state`：15
- `scan_meta.stop_reason_detail:评论区显示暂无评论或抢首评`：15
- `scan_meta.warning:comment response parse failed: https://www.douyin.com/passport/web/challenge/?passport_jssdk_version=3.1.3&passport_jssdk_type=normal&is_from_ttaccountsdk=1&aid`：8
- `scan_meta.warning:comment response parse failed: https://api.feelgood.cn/athena/survey/platform/task/show/: Response.json: Protocol error (Network.getResponseBody): No resource w`：5
- `scan_meta.warning:comment response parse failed: https://www.douyin.com/passport/token/beat/web/?passport_jssdk_version=3.1.3&passport_jssdk_type=normal&is_from_ttaccountsdk=1&ai`：3
- `scan_meta.warning:comment response parse failed: https://lf-douyin-pc-web.douyinstatic.com/obj/douyin-pc-web/ies/douyin_web/media/commentTmptyList-dark.e420bfbf10e5d0c3.png: 'utf`：3
- `scan_meta.warning:comment response parse failed: https://api.feelgood.cn/athena/survey/platform/action/report/: Response.json: Protocol error (Network.getResponseBody): No resour`：2
- `raw.response_url:www.douyin.com/aweme/v1/web/aweme/related/`：2
- `scan_meta.warning:comment response parse failed: https://www.douyin.com/aweme/v1/creator/external/highlight/?device_platform=webapp&aid=6383&channel=channel_pc_web&highlight_type`：2
- `scan_meta.warning:comment response parse failed: https://security.zijieapi.com/api/metrics/emit: Response.json: Protocol error (Network.getResponseBody): No resource with given i`：1
- `scan_meta.warning:comment response parse failed: https://www.douyin.com/aweme/v1/web/aweme/related/?device_platform=webapp&aid=6383&channel=channel_pc_web&aweme_id=75789302608597`：1
- `scan_meta.warning:comment response parse failed: https://mcs.zijieapi.com/webid: Response.json: Protocol error (Network.getResponseBody): No resource with given identifier found`：1
- `scan_meta.warning:comment response parse failed: https://www-hj.douyin.com/aweme/v1/web/query/user/?device_platform=webapp&aid=6383&channel=channel_pc_web&publish_video_strategy_`：1
- `scan_meta.warning:comment response parse failed: https://www.douyin.com/recharge_web_vmok/vmok-manifest.json: Response.json: Protocol error (Network.getResponseBody): No resource`：1

### missing_artifact

- 无可聚合原因


## 视频明细

| 视频 ID | 状态 | 评论预期分类 | 详情评论数 | 产物数 | 评论数 | 真实评论数 | 主要失败原因 |
| --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1234567890 | empty_response | no_comment_expected | 0 | 1 | 0 | 0 | `scan_meta.backend:stub:no_playwright` |
| 7022771022038388255 | noise_only | comment_expected_noise_only | 2026 | 7 | 20 | 0 | `scan_meta.warning:dom_json_extraction_used` |
| 7158035664578120992 | noise_only | comment_expected_noise_only | 2026 | 5 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7210685046527724839 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7238440037585521975 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7242464948482346243 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7262338680969317644 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7268207295228595517 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7309260705960660224 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7329857128615677225 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7356441851857063180 | noise_only | comment_expected_noise_only | 2026 | 5 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7377711055939570944 | noise_only | comment_expected_noise_only | 2026 | 5 | 20 | 0 | `scan_meta.warning:dom_json_extraction_used` |
| 7390661320661650738 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7395782642211294490 | noise_only | comment_expected_noise_only | 2026 | 5 | 19 | 0 | `scan_meta.warning:dom_json_extraction_used` |
| 7396156664715529513 | noise_only | comment_expected_noise_only | 2026 | 4 | 20 | 0 | `raw.response_url:live.douyin.com/webcast/setting/` |
| 7401376785981590810 | noise_only | comment_expected_noise_only | 2026 | 4 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7428526697953234214 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7429640163434827017 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7430739609820122378 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7431130550506753289 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7431505851178945849 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7432310457010031931 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7433419621086039347 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7433800078784990524 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7434149622014151987 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7434532394339781945 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7435995375317683465 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7436299526991809818 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7436351016179666236 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7436768028760542524 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7437120651657366841 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7438606391218146618 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7438987865108876596 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7438988323839823156 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7438994866463362364 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7439367997023620409 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7439738596522855739 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7439752166480301353 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7441145394341367099 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7441222380841733402 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7441574817381338426 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7441946012723334458 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7442129556930104636 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7442276294982749467 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7442639037904489786 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7443658872721657139 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7443659442500996378 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7443659735284419850 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7444165516056366396 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7444602190511050042 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7444934745273814330 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7446004235470261561 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7446304731636452649 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7446771026169548091 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7447091622954749241 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7447126737764289855 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7447508493193547065 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7449006240644091136 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7449745077892664610 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7450713355175595298 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7451259770419383592 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7451515673336958218 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7451515829532888357 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7452287155893751099 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7453473047949921536 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7454097131893214500 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7454097385933868324 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7454540261251747130 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7456786755501477177 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7459392006113021241 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7490481680940158219 | noise_only | comment_expected_noise_only | 2026 | 4 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7491286799751466294 | noise_only | comment_expected_noise_only | 2026 | 4 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7492374897897770292 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7493172181942242570 | noise_only | comment_expected_noise_only | 2026 | 4 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7505098187544300859 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7509478674196303162 | noise_only | comment_expected_noise_only | 2026 | 4 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7512051851359440187 | noise_only | comment_expected_noise_only | 2026 | 4 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7512657129670266170 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7519786603025747260 | noise_only | comment_expected_noise_only | 2026 | 4 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7522376955615235388 | noise_only | comment_expected_noise_only | 2026 | 4 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7524180984691985699 | noise_only | comment_expected_noise_only | 2026 | 4 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7530172132748594484 | noise_only | comment_expected_noise_only | 2026 | 2 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7533089749390363939 | noise_only | comment_expected_noise_only | 2026 | 3 | 40 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7540976681524202809 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7542469855435656506 | noise_only | comment_expected_noise_only | 2026 | 2 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7548718604976786722 | noise_only | comment_expected_noise_only | 2026 | 2 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7556188189237857570 | noise_only | comment_expected_noise_only | 2026 | 2 | 13 | 0 | `raw.response_url:live.douyin.com/webcast/setting/` |
| 7569213560669228324 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7573943256346561835 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7574714844406926632 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7576457520319876387 | noise_only | no_comment_observed | 147000 | 4 | 8 | 0 | `raw.response_url:live.douyin.com/webcast/setting/` |
| 7578770173448998182 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7578930260859735306 | noise_only | no_comment_observed | 27000 | 5 | 8 | 0 | `scan_meta.warning:dom_json_extraction_used` |
| 7579172277862829318 | noise_only | no_comment_observed | 65000 | 5 | 9 | 0 | `scan_meta.warning:dom_json_extraction_used` |
| 7587611191427157254 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7590439728747818426 | noise_only | comment_expected_noise_only | 2026 | 2 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7592835997059008403 | noise_only | comment_expected_noise_only | 2026 | 2 | 20 | 0 | `scan_meta.warning:comment response parse failed: https://mcs.zijieapi.com/list?aid=6383&sdk_version=5.1.24_dy: Response.json: Protocol error (Network.getResponseBody): No resourc` |
| 7594044392240487144 | noise_only | comment_expected_noise_only | 2026 | 2 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7597010506452972401 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7598026400116821283 | noise_only | comment_expected_noise_only | 2026 | 3 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7598477676449500425 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7602211938659061019 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7602214435578531099 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7603037411383332096 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7603037614651821363 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7603037742095781155 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7603040655950056731 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7603041691007864079 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7603578926765493513 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7604745127566789923 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7604745443381169443 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7604746875190742306 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7604747266020101411 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7604747764878118196 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7604751321136123176 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7604752969820638504 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7604754049392463110 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7604756050276863273 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7605132684360256818 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7605144720943140146 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7605145876050267430 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7605146884742696207 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7605428442015763718 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7606174762963946795 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7606175597160598825 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7606176672806686006 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7606178085892951338 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7606313324778720527 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7606323718058478888 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7606325459546017076 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7606326121919040783 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7606328229900619008 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7606339863243197736 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7609544473068064038 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7609546271648386313 | empty_response | no_comment_expected | 0 | 2 | 0 | 0 | `scan_meta.warning:dom_json_extraction_used` |
| 7609547134546791690 | empty_response | comment_expected_empty_response | 2 | 1 | 0 | 0 | `scan_meta.backend:playwright:placeholder` |
| 7609709232513912115 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7609709716494732553 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7610712202441706752 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7611084991157636386 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7611743003136380214 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7611751806799990054 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7611857682466737417 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7611858014152297738 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7611858428184595763 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7611859884216306990 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7611860472714857779 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7611860833118817586 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7611861518111493402 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7611862054290410778 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7612548764947008778 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7612555779077377290 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7613006074005720371 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7613292904898923830 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7613295001811815721 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7613365857418251574 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7613735970894056744 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7614087197595061519 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7614110722506657070 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7614111242562571530 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7615176799684758822 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7615210889188216098 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7615518953196047631 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7615543035740425507 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7615544065676823843 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7615545466985434422 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7615546744612359424 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7615548245057604864 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7615572186471992576 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7615579790229228809 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7615821615388970240 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7615835354280561972 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7615882777518427434 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7615952663099772194 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7616316623728758025 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7616317119931747611 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7616567906117192994 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7616634912539479315 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7616647784996932864 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7616668756982385960 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7616669161523105067 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7616670006402649386 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7616684336808611099 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7616685611704929563 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7617753997981666575 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7617754766877429035 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7617803032478207247 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7618166434270579968 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7618533394862968064 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7618904356183657743 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7618918674066258090 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7619152911297285376 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7619271436011703558 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7619272548647259433 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7619274342131649811 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7619274748534492457 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7620635669420854580 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7620668275915001140 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7621020837084204340 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7621380906221079842 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7621832520975338761 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7621832524913806628 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7621851099045170441 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7622279688114703659 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7622281565019606313 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7622928424377617704 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7622928763159989544 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7622993693792046376 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7623297461745995008 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7623349803124133147 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7623371395589852462 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7623671623853346094 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7623672121822121243 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7623672440165649674 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7623738093828312363 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7624048954216353039 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7624050431437655336 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7624054449819897128 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7624060804744121646 | empty_response | comment_expected_empty_response | 2 | 1 | 0 | 0 | `scan_meta.backend:playwright:placeholder` |
| 7624066563250949376 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7624067374781582627 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7624071419617414452 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7624076563646139699 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7624079514745802011 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7625953016668127338 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7626303539492490531 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7626327409453185765 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7626332481964363043 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7626672649321663794 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7626703445458383033 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7626946287597833522 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7626947588230565129 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7626948538512969011 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7628140545419791667 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7628141304916020507 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7628141621011352858 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7628142161233513778 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7628142514440047899 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7628142865369025818 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7628145211587317043 | missing_artifact | comment_expected_missing_artifact | 2 | 0 | 0 | 0 | `-` |
| 7628145470333914414 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7628149571465563430 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7628157324573625609 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7628168191214226734 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7628443797914979584 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7628553092715367715 | empty_response | no_comment_expected | 0 | 6 | 0 | 0 | `scan_meta.warning:dom_json_extraction_used` |
| 7628561587124587776 | empty_response | comment_expected_empty_response | 3 | 2 | 0 | 0 | `scan_meta.backend:playwright:placeholder` |
| 7628901347772960050 | missing_artifact | comment_expected_missing_artifact | 2 | 0 | 0 | 0 | `-` |
| 7628911612753136896 | missing_artifact | comment_expected_missing_artifact | 2 | 0 | 0 | 0 | `-` |
| 7629650019401911592 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7629661886748839202 | empty_response | comment_expected_empty_response | 2 | 2 | 0 | 0 | `scan_meta.backend:playwright:placeholder` |
| 7629663006846110991 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7629665802664348978 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7630900261497621812 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7631043782183521578 | noise_only | no_comment_observed | 12000 | 5 | 9 | 0 | `scan_meta.warning:dom_json_extraction_used` |
| 7631099317763198214 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7631100653305072938 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7631105657705483539 | missing_artifact | comment_expected_missing_artifact | 2 | 0 | 0 | 0 | `-` |
| 7631108731064896804 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7631134550736103744 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7631152806283513103 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7631153680381495910 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7631163112623852835 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7631200329728098047 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7631507630095109402 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7631510151031295259 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7631519934966779163 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7631747747398485503 | missing_artifact | comment_expected_missing_artifact | 1 | 0 | 0 | 0 | `-` |
| 7631773429788519138 | noise_only | comment_expected_noise_only | 2026 | 2 | 20 | 0 | `raw.response_url:api.feelgood.cn/athena/survey/platform/action/report/` |
| 7631786804228318656 | noise_only | no_comment_observed | 226000 | 6 | 8 | 0 | `scan_meta.warning:dom_json_extraction_used` |
| 7631842485924387151 | missing_artifact | no_comment_expected | 0 | 0 | 0 | 0 | `-` |
| 7631881161303690530 | missing_artifact | comment_expected_missing_artifact | 2 | 0 | 0 | 0 | `-` |
