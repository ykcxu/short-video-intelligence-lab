# 运行状态总览

- 生成时间：2026-04-28T07:19:55.696485+00:00
- 工作区：C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab

## 状态文件
- project_progress: 存在（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\status\project_progress.json）
  - 指标：download_goal_progress=1.0，detail_coverage_progress=1.0，comment_quality_progress=0.9363636363636364，download_goal_downloaded_videos=576，download_goal_target_videos=450，account_count=9
- data_quality_report: 存在（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\status\data_quality_report.json）
  - 指标：invalid_video_id_count=6，download_without_detail_count=0，detail_without_download_count=3，detail_metric_anomalies_count=34
- positive_factors_report: 存在（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\analysis\positive_factors_report.json）
  - 指标：account_count=10，top_n=10，dataset_rows=None
- positive_factors_strict_valid_report: 存在（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\analysis\positive_factors_strict_valid_report.json）
  - 指标：account_count=8，top_n=10，dataset_rows=None
- strict_pool_gap_report: 存在（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\status\strict_pool_gap_report.json）
  - 指标：input_video_count=628，valid_video_count=362，overall_retention_rate=0.5764，high_priority_account_count=3
- strict_pool_backfill_targets: 存在（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\analysis\strict_pool_backfill_targets.json）
  - 指标：target_count=5，high_priority_target_count=2
- backfill_download_status: 存在（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\status\backfill_download_status.json）
  - 指标：target_count=5，needs_dataset_refresh_count=2，local_mp4_total=298
- comment_backfill_status: 存在（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\status\comment_backfill_status.json）
  - 指标：comment_artifact_count=518，comment_video_count=389，real_comment_video_count=351，empty_comment_video_count=8，noise_only_video_count=30，total_real_comment_count=1923，comment_backfill_targets.target_count=272，comment_backfill_targets.planned_count=272
- comment_failure_diagnostics: 存在（C:\Users\Administrator\Desktop\codex\short-video-intelligence-lab\artifacts\status\comment_failure_diagnostics.json）
  - 指标：summary.video_count=272，summary.hit_rate=0.0，status_counts.missing_artifact=235，status_counts.noise_only=30，status_counts.empty_response=7

## 最近日志
- 扫描文件总数：181（纳入最近 25 条，limit=25）
- 最近批处理相关日志数：5
- 错误日志数：4（非空 2）

### 最新日志明细
- comment_backfill_expected_douyin_main_20260428_1530.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T07:18:51.385619+00:00
- comment_backfill_expected_douyin_main_20260428_1530_inner.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T07:18:51.349607+00:00
- comment_backfill_expected_douyin_main_20260428_1510_inner.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:58:11.631584+00:00
- comment_backfill_expected_douyin_main_20260428_1510.log | non_empty=False | is_error=False | is_batch=False | 2026-04-28T06:57:25.032496+00:00
- comment_backfill_expected_douyin_main_20260428_1450.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:50:53.444824+00:00
- comment_backfill_expected_douyin_main_20260428_1450_inner.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:50:53.433501+00:00
- comment_backfill_expected_20260428_1444.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:44:28.789563+00:00
- comment_backfill_expected_20260428_1444_inner.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:44:28.774498+00:00
- run_multimodal_batch_real1_20260428.err.log | non_empty=True | is_error=True | is_batch=True | 2026-04-28T06:34:36.530543+00:00
- run_multimodal_batch_real1_20260428.out.log | non_empty=True | is_error=False | is_batch=True | 2026-04-28T06:34:36.481943+00:00
- run_multimodal_batch_skip_20260428.out.log | non_empty=True | is_error=False | is_batch=True | 2026-04-28T06:33:51.969003+00:00
- run_multimodal_batch_dry_20260428.out.log | non_empty=True | is_error=False | is_batch=True | 2026-04-28T06:33:20.095700+00:00
- multimodal_fusion_two_video_pose_full_real_20260428.out.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:25:29.433491+00:00
- multimodal_inputs_two_video_pose_full_real_20260428.out.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:25:29.296784+00:00
- person_visual_features_two_video_pose_real_20260428.err.log | non_empty=True | is_error=True | is_batch=False | 2026-04-28T06:25:29.152072+00:00
- person_visual_features_two_video_pose_real_20260428.out.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:25:29.102797+00:00
- multimodal_fusion_two_video_full_real_20260428.out.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:21:35.709598+00:00
- multimodal_inputs_two_video_full_real_20260428.out.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:21:35.514043+00:00
- person_visual_features_two_video_real_20260428.out.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:21:35.368935+00:00
- person_visual_features_two_video_real_20260428.err.log | non_empty=False | is_error=True | is_batch=False | 2026-04-28T06:21:33.520823+00:00
- person_visual_help_20260428.out.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:19:42.553426+00:00
- comment_backfill_missing_artifact_limit50_20260428.out.log | non_empty=True | is_error=False | is_batch=False | 2026-04-28T06:14:00.523346+00:00
- comment_backfill_batch_20260428_135610.log | non_empty=True | is_error=False | is_batch=True | 2026-04-28T06:13:59.976408+00:00
- comment_backfill_missing_artifact_limit50_20260428.err.log | non_empty=False | is_error=True | is_batch=False | 2026-04-28T05:56:10.122729+00:00
- run_comment_backfill_limit50_20260428.ps1 | non_empty=True | is_error=False | is_batch=False | 2026-04-28T05:56:09.862633+00:00

## Warnings
- 无
